const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");

const PORT = process.env.PORT || 3000;
const INDEX = path.join(__dirname, "public", "index.html");

function decodeEntities(value = "") {
  return value
    .replace(/&amp;/g, "&").replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'").replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">").replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCharCode(parseInt(n, 16)))
    .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n)));
}
function meta(html, key) {
  const escaped = key.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const patterns = [
    new RegExp(`<meta[^>]+property=["']${escaped}["'][^>]+content=["']([^"']*)["'][^>]*>`, "i"),
    new RegExp(`<meta[^>]+content=["']([^"']*)["'][^>]+property=["']${escaped}["'][^>]*>`, "i"),
    new RegExp(`<meta[^>]+name=["']${escaped}["'][^>]+content=["']([^"']*)["'][^>]*>`, "i")
  ];
  for (const pattern of patterns) { const m = html.match(pattern); if (m) return decodeEntities(m[1]); }
  return "";
}
function send(res, status, body) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" });
  res.end(JSON.stringify(body));
}
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  if (url.pathname === "/api/health") return send(res, 200, { ok: true });
  const match = url.pathname.match(/^\/api\/profile\/([a-zA-Z0-9]{1,20})$/);
  if (req.method === "GET" && match) {
    const username = match[1];
    const target = `https://www.paypal.me/${encodeURIComponent(username)}`;
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 8000);
      const response = await fetch(target, {
        method: "GET",
        redirect: "follow",
        signal: controller.signal,
        headers: { "User-Agent": "Mozilla/5.0 (compatible; PublicProfileLookup/1.0)", "Accept": "text/html,application/xhtml+xml" }
      });
      clearTimeout(timer);
      if (response.status === 404 || response.status === 410) {
        return send(res, 200, { found: false, title: "Página não encontrada", message: "Não encontramos uma página pública para esse identificador. Isso não confirma se a pessoa possui uma conta PayPal." });
      }
      if (!response.ok) {
        return send(res, 200, { found: false, title: "Não foi possível confirmar", message: `O PayPal respondeu com status ${response.status}. Tente novamente mais tarde.` });
      }
      const finalUrl = new URL(response.url);
      if (finalUrl.hostname !== "www.paypal.me" && finalUrl.hostname !== "paypal.me") {
        return send(res, 200, { found: false, title: "Página não confirmada", message: "O PayPal redirecionou a consulta; não foi possível confirmar o perfil." });
      }
      const html = (await response.text()).slice(0, 2_000_000);
      const titleTag = (html.match(/<title[^>]*>([\s\S]*?)<\/title>/i) || [,""])[1].replace(/<[^>]+>/g, "").trim();
      const ogTitle = meta(html, "og:title");
      const description = meta(html, "og:description") || meta(html, "description");
      const photoUrl = meta(html, "og:image") || meta(html, "twitter:image");
      const pageTitle = ogTitle || titleTag || "";
      const looksUnavailable = /not found|page isn.t available|something went wrong|page unavailable|não foi possível|não encontrado/i.test(pageTitle + " " + description);
      if (looksUnavailable || (!pageTitle && !photoUrl && !description)) {
        return send(res, 200, { found: false, title: "Perfil não confirmado", message: "A página não forneceu metadados públicos suficientes. Isso não prova que a conta não existe." });
      }
      let displayName = pageTitle
        .replace(/\s*[|–-]\s*PayPal\.?Me.*$/i, "")
        .replace(/\s*[|–-]\s*PayPal.*$/i, "")
        .trim();
      if (!displayName || /^paypal(\.me)?$/i.test(displayName)) displayName = username;
      let safePhoto = "";
      if (photoUrl) {
        try { const parsed = new URL(photoUrl, response.url); if (parsed.protocol === "https:" && (parsed.hostname === "paypalobjects.com" || parsed.hostname.endsWith(".paypalobjects.com") || parsed.hostname === "www.paypal.com" || parsed.hostname.endsWith(".paypal.com"))) safePhoto = parsed.href; } catch {}
      }
      return send(res, 200, {
        found: true, username, displayName, photoUrl: safePhoto,
        message: "Informações públicas lidas da página PayPal.Me. A página pode não expor todos os campos."
      });
    } catch (error) {
      return send(res, 200, { found: false, title: "Consulta indisponível", message: "Não foi possível consultar a página pública neste momento. Isso não prova que a conta não existe." });
    }
  }
  if (req.method === "GET" && (url.pathname === "/" || url.pathname === "/index.html")) {
    fs.readFile(INDEX, (err, data) => {
      if (err) { res.writeHead(500); return res.end("index.html não encontrado"); }
      res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "X-Content-Type-Options": "nosniff" });
      res.end(data);
    });
    return;
  }
  res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" }); res.end("Not found");
});
server.listen(PORT, () => console.log(`PayPal Profile Finder rodando em http://localhost:${PORT}`));
