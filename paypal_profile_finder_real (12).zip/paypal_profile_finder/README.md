# PayPal Profile Finder — consulta de páginas públicas

Esta versão substitui os perfis fictícios por uma tentativa de consulta da página pública `https://www.paypal.me/<username>` no servidor. Se a página responder com metadados públicos, o site tenta mostrar o nome e a foto dentro da própria interface.

## Executar localmente
1. Instale Node.js 18 ou mais recente.
2. Na pasta do projeto, execute `npm start`.
3. Abra `http://localhost:3000`.

## Hospedagem
Este projeto agora precisa de hospedagem que execute Node.js (por exemplo, um serviço de aplicação Node). Hospedagem puramente estática não executará `server.js`.

## Limitações importantes
- O PayPal não oferece um endpoint público universal para pesquisar todas as contas pelo username. Este projeto apenas tenta consultar uma página pública PayPal.Me correspondente.
- Se o perfil estiver oculto, a página usar JavaScript, bloquear a consulta, mudar seu HTML ou não expor metadados, o site pode não conseguir obter nome/foto.
- Um username válido, uma página acessível ou metadados encontrados não garantem a identidade do titular nem que a conta esteja ativa.
- Não há bypass de login, CAPTCHA ou privacidade. Não envie senhas ou dados de autenticação para este site.
- Antes de uso comercial ou consultas em volume, verifique os termos do PayPal e obtenha autorização quando necessário. A estrutura pode exigir ajuste técnico se o PayPal não permitir a consulta automatizada ou alterar a página.

## Como funciona
O navegador chama `/api/profile/:username` no próprio servidor. O servidor consulta somente o host fixo `www.paypal.me`, lê metadados públicos (`og:title`, `og:image`, descrição) e retorna os campos encontrados. A URL de destino não é fornecida pelo usuário, evitando que o endpoint seja usado como proxy arbitrário.
